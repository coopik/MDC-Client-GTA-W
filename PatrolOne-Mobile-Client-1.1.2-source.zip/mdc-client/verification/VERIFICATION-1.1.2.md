# PatrolOne Mobile Client 1.1.2 verification

Release date: 2026-10-20.

## Requested fixes

Page-tab close controls use the current Aero palette's glass hover, border and
inset pressed state. Aero LAPD keeps a white X; the other Aero palettes retain
their own text color. Default keeps its neutral chrome and a distinct pressed
state. Tooltips and page-close behavior are unchanged.

Only Aero LAPD's dock palette changes. It reuses the existing nav/page gradient
variables, white text, brighter active face and matching close hover/press. The
record-color strip remains 3 CSS pixels; it mixes the saved record color with
20 percent white for readability on blue. Other dock faces, reserved space,
record persistence and restore/close behavior are unchanged.

MCP measured Arial, sans-serif on the supplied Incident add-person button and
its generated glyph. The winning rule was the shared header-action selector
html[class] body :is(.card-header,.panel-heading) .btn, whose important
font shorthand replaced the Font Awesome family. Generic skin font declarations
now exclude known icon hosts, including selectors ending in before/after.
The real add-person and trash buttons now compute to Font Awesome 5 Free and
render their original glyphs. Shared create-page primary actions have compact
faces, borders and padding; plain label chips have consistent spacing. Modal
arrest layout and editor geometry remain excluded.

The supplied warrant script calls $('.inner').perfectScrollbar() after adding
charges. bootstrap-select uses .inner on its native scrolling div and its option
UL. The real plugin adds rails inside the protected widget subtree, where the
skin's generic rail cleanup was excluded. MCP measured a native inner-list
gutter alongside the plugin's 15px rail and 6px thumb. A dedicated picker rule
suppresses those plugin rails and thumbs. The native div.inner remains the sole
visible list scrollbar; the outer menu stays overflow hidden and search stays
outside the scrolling div. The plugin is not destroyed and its appearance can
resume when skin CSS is removed.

## Validation

- npm run smoke passed after each of the four fixes and after final integration.
  Each run is included separately.
- The 1.1.2 Electron suite passed 97 checks, starting with Aero LAPD, then Aero,
  Aero Dark and Default. Checks include native pointer hover/press, actual record
  minimization, dock type strip, supplied Incident buttons and icon fonts, the
  actual Perfect Scrollbar plugin on Charge/Addition/Class in both arrest and
  warrant forms, fixed height, pinned search, wheel isolation, scrollbar-thumb
  dragging, filtering, keyboard highlight bounds and Enter selection.
- The shared create/edit and document suite passed 35 checks across skins,
  including representative APB, warrant, report, arrest and custom forms, native
  Incident structure, arrest layout and printed documents.
- Electron MCP screen checks started in Aero LAPD and ended with Default. The
  page-tab hover/press, blue dock, Incident plus/trash glyphs, compact linked
  actions/chips and single dropdown scrollbar were inspected. MCP measured the
  native list with a 10px reserved gutter and all added plugin rails hidden.
- The full historical regression suite was not rerun for this release. The
  included logs document the targeted checks actually completed.
- The ZIP is CRC-tested and every packaged source hash is verified against
  source-sha256.json.

## Scope

Checks use an isolated Electron profile and supplied MDC source snippets, real
Bootstrap/bootstrap-select/Material/Summernote/Font Awesome resources and the
site's Perfect Scrollbar 0.6.13. The hidden native person template is displayed
locally. Fixture avatars are unavailable; no real person is created. Shared
APB/report/arrest create/edit pages are representative fixtures where complete
source was not supplied. This is source-fixture validation, not a live account
check. No forms were submitted and no account pages were contacted.

The archive contains all project source and release evidence. Installed
dependencies, build output, unrelated logs and older archives are excluded.
Run npm ci before starting from source.
