# PatrolOne Mobile Client 1.1.3 verification

Release date: 2026-10-25; checks performed 2026-10-24 through 2026-10-25. Electron 31 on Windows. Temporary isolated user data; HTTPS
requests served from local fixtures and bundled vendor assets. No live MDC
record was changed and no account session was used.

The update targets record-page rendering, native charge-list opening and narrative typing.
The new PatrolOne Dark setting is p1dark; legacy dark preferences retain their
previous migration to Default.

## Checks

- npm run smoke passes.
- npm run verify -- --release113-only passes 40 reported checks, covering menu,
  Options, F8, persistence, dark fields and button/toolbar contrast, icon fonts,
  dynamically inserted and newly shown modal text, both arrest and warrant
  charge pickers, wheel containment, fixed height, pinned search, filtered Enter
  selection, virtualized keyboard visibility, restoration on close/Original,
  printed document surfaces, law-topic colors and native authentication.
- The complete post-fix run passes all 728 reported checks, including native typing
  in every skin. Full output is recorded in release-1.1.3-typing-full.log.
- A separate final typing run covers 58 checks, including late editor creation,
  reset and destruction cleanup, with output in release-1.1.3-typing-final-checks.log.
  The original pre-correction 674-check log is retained as earlier release evidence.
- Electron MCP on-screen inspection covered Dark record details, copied plate
  identifiers, the native arrest charge list, scrolling/filtering, editor chrome
  and white paper reports. This inspection caught and corrected a pale Default
  button gradient overriding the new Dark button faces. Automated screenshots
  accompany the package.

## Performance method

release-1.1.3-before-metrics.json was captured before these optimizations at
version 1.1.2; the after file measures the final candidate. The harness loads the
supplied person-record source and native warrant markup, with 350 charge options,
three times in each version. Backend and network time are excluded. Each record
sample includes local navigation and 250ms settling; each picker sample includes
native opening and 350ms settling; duplicate-skin samples send three identical
settings and wait 450ms. Fixed waits are included in elapsed time.

Compare median TaskDuration for total main-thread work: ScriptDuration alone
omits much of the isolated preload work. Raw CPU profiles for the first sample
of each workload are included. Timing varies with host load. Idle-clock metrics
are included separately; they are not the record/dropdown benchmark.

## Compatibility

The native bootstrap-select renderer is used rather than replacing its DOM,
filtering or selection. Numeric virtualization thresholds above 80 are lowered
temporarily; false, true and existing lower thresholds are respected. Native
options and frozen menu sizing restore on close or Original MDC. No vendor files
or production dependencies were changed.

The existing File Warrant test assumed red buttons in every skin. It failed in
the delivered 1.1.2 source ZIP as well, because Aero intentionally uses its glass
button palette. The assertion now checks readable contrast and the native ripple
opacity, retaining coverage of the original white-on-white bug. Performance
thresholds and layout/scrolling expectations were not relaxed.

The ZIP contains the full source project and verification evidence, excluding
node_modules, generated builds, Git metadata and previous archives. It includes
a SHA-256 manifest for the source files. Install dependencies with npm ci.

## Final three-sample medians

- Record loading: 1163.7ms before, 997.4ms after; 14.3 percent less main-thread work.
- Charge opening: 596.2ms before, 392.1ms after; 34.2 percent less main-thread work.
- Three identical skin messages: 336.3ms before, 85.7ms after; 74.5 percent less main-thread work.
- Native picker opening handler: 207.6ms before, 131.1ms after.

Final profiles identify version 1.1.3. Earlier candidate runs varied with host load;
the README and changelog use the final run above. The idle-clock check remained
responsive, with 13 ticks and roughly 4.3ms of script time in its four-second sample.


## Typing correction within 1.1.3

The replacement ZIP keeps version 1.1.3. Native Summernote updates its toolbar on
both change and keyup, rewriting font labels even when the current selection's
formatting is unchanged. These writes cause repeated style recalculation and
layout with the skin stylesheet. Isolating the base stylesheet reproduced the
difference; layout containment and changing Dark-specific colors did not fix it.

The page bridge caches only the scalar formatting state per native toolbar
target. It invokes the native update immediately on a changed state, leaves all
input/selection/history processing untouched, and restores the exact native
method on Original MDC and editor destruction. Newly initialized or reset
editors receive the same hook. No native vendor file or scrollbar rule changes
were retained.

The typing baseline is the initially delivered 1.1.3, separate from the earlier
1.1.2 record-loading baseline. It uses native Electron keyDown/char/keyUp events
for a 30-character sentence at a requested 35ms cadence, two samples per skin.
JSON includes actual send/input/frame-callback timestamps, retained text, total
main-thread work, style/layout time and raw CPU profiles. The after check covers
all five custom skins and Original MDC, preserves every character, bounds frame
delay/style work, verifies native bold/font state, undo, Original restoration,
and initialization/reset/destruction. The comparison is a local rendering
measurement, not a guarantee about every PC or live network response.

Electron MCP inspection used the visible, isolated local fixture window with
real Summernote, native text insertion and formatting in Dark and Default. The
review helper can bring its window forward on request to avoid screenshots of
an occluded cached frame. No record was submitted.

The final targeted run passed 58 checks. In its two Dark samples, mean style
recalculation time fell from 846.5ms to 31.2ms (96.3 percent less).
The worst observed send-to-frame-callback delay changed from 861ms to
90ms. Input/frame timestamps and CPU profiles are included for review.
